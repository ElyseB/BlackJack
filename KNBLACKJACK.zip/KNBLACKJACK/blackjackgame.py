import random 

class Card:
    'represents a playing card'
    def __init__(self, rank, suit):
        'initialize rank and suit of playing card'
        self.rank = rank
        self.suit = suit
    def getRank(self):
        'return rank'
        return self.rank
    def getSuit(self):
        'return suit'
        return self.suit
    def prettyString(self):
        return self.rank+self.suit

class Deck:
    'represents a deck of 52 cards'
    # ranks and suits are Deck class variables
    ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    # suits is a set of 4 Unicode symbols representing the 4 suits
    suits = ['C', 'S', 'H', 'D']
    def __init__(self):
        'initialize deck of 52 cards'
        self.deck = [] # deck is initially empty
        for suit in Deck.suits: # suits and ranks are Deck 
            for rank in Deck.ranks: # class variables
                # add Card with given rank and suit to deck
                #print(rank+suit)
                self.deck.append(Card(rank, suit))
    def emptyDeck(self):
        self.deck = []
        return self.deck
    def deckAddACard(self,card):
        self.deck = self.deck + [card]
    def dealCard(self):
        'deal (pop and return) card from the top of the deck'
        if len(self.deck)== 0:
            raise OutOfCards()
        else:
            return self.deck.pop()
    def shuffle(self):
        'shuffle the deck'
        return random.shuffle(self.deck)

class Hand:
    def __init__(self):
        'represents the player hand'
        self.house = []  # house hand
        self.player = [] # player hand
    def initialHand(self,deck):
        for i in range(2):        # dealing initial hands in 2 rounds
            self.playerAddACard(deck.dealCard())    # deal to player first
            self.houseAddACard(deck.dealCard())     # deal to house second
    def printHands(self):
          # print hands
        print('House:{:>7}{:>7}'.format(self.house[0].prettyString(),\
              self.house[1].prettyString()))
        print('You:{:>7}{:>7}'.format(self.player[0].prettyString(),\
              self.player[1].prettyString()))       
    def total(self,hand):
      'returns the value of the blackjack hand'
      values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8,
      '9':9, '10':10, 'J':10, 'Q':10, 'K':10, 'A':11}
      result = 0
      numAces = 0
      # add up the values of the cards in the hand
      # also add the number of aces
      for card in hand:
            result += values[card.getRank()]
            if card.getRank() == 'A':
                  numAces += 1
      # while value of hand is > 21 and there is an ace
      # in the hand with value 11, convert its value to 1
      while result > 21 and numAces > 0:
            result -= 10
            numAces -= 1
      return result
    def compareHands(self,record):
        'compares house and player hands and prints outcome'
        # compute house and player hand total
        houseTotal, playerTotal = self.total(self.house), self.total(self.player)
        if houseTotal > playerTotal:
            print('You lose.')
            record.increaseHouseScore()
        elif houseTotal < playerTotal:
            print('You win.')
            record.increasePlayerScore()
        elif houseTotal == 21 and 2 == len(self.house) < len(self.player):
            print('You lose.') # house wins with a blackjack
            record.increaseHouseScore()
        elif playerTotal == 21 and 2 == len(self.player) < len(self.house):
            print('You win.') # players wins with a blackjack
            record.increasePlayerScore()
        else:
            print('A tie.')
            record.increasePlayerTies()
    def playerAddACard(self,card):
        self.player = self.player + [card]
    def houseAddACard(self,card):
        self.house = self.house + [card]
class Record:
    'represents the win/loss record'
    def __init__(self, housewins=0, playerwins=0, playerties=0):
        'initialize win/loss record'
        self.housewins = housewins
        self.playerwins = playerwins
        self.playerties = playerties
    def getHouseWins(self):
        'return housewins'
        return self.housewins
    def getPlayerWins(self):
        'return playerwins'
        return self.playerwins
    def increaseHouseScore(self):
        'change house wins'
        self.housewins = self.housewins +1
        return self.housewins
    def increasePlayerScore(self):
        'return playerwins'
        self.playerwins = self.playerwins +1
        return self.playerwins
    def increasePlayerTies(self):
        'return playerties'
        self.playerties = self.playerties +1
        return self.playerties
    def getRecord(self):
        totalgames = self.playerwins + self.housewins + self.playerties
        if totalgames == 0:
            winpercent = 0.0
        else:    
            winpercent = (self.playerwins / totalgames) * 100
        return [self.playerwins,self.housewins,self.playerties,totalgames,winpercent]
    def printRecord(self):
    	print('The Game is over! You have won', self.playerwins,'you tied', self.playerties, 'games and the ' + \
        'dealer has won',self.housewins,'games')
    	if self.housewins>self.playerwins:
    		print('You lost overall')
    	elif self.housewins<self.playerwins:
    		print('You won overall')
    	elif self.housewins==self.playerwins:
    		print('You tied overall')

    #compare hands here?

class OutOfCards(Exception):
    'Out of cards'
    pass

class Blackjack:
    'mechanics of actual game'
    def __init__(self):
        self.hand = Hand()
        self.deck = Deck()
        self.record = Record()
    def dealerPlay(self):
        while self.hand.total(self.hand.house) < 17:
            card = self.deck.dealCard()
            self.hand.houseAddACard(card)
            print('House got{:>7}'.format(card.prettyString()))
        return 
    def playBlackjack(self):
        self.deck.shuffle()
        while(True):
            try:
                self.hand.initialHand(self.deck) #deal two cards to each player
            except OutOfCards:
                self.record.printRecord()
                return self.record.getRecord()    
            # print hands
            self.hand.printHands()
            # while user requests an additional card, house deals it
            answer = input('Hit or stand? (defaul: hit): ')
#            answer = userinput('Hit or stand? (default: hit): ')
            #answer = getinput(total(house), total(player))
            while answer in {'', 'h', 'hit'}:
                try:
                    card = self.deck.dealCard()
                    self.hand.playerAddACard(card)
                except OutOfCards:
                    self.record.printRecord() #Out of cards - quit
                    return self.record.getRecord()
                print('You got{:>7}'.format(card.prettyString()))
                if self.hand.total(self.hand.player) > 21:      # player total is > 21
                      print('You went over… You lose.')
                      self.record.increaseHouseScore()
                      break
                else:
                      answer = input('Hit or stand? (defaul: hit): ')
#                      answer = userinput('Hit or stand? (default: hit): ')
            #answer = getinput(total(house), total(player))
            # house must play the “house rules”
            if(self.hand.total(self.hand.player)<=21):
                try:
                    self.dealerPlay()
                    if(self.hand.total(self.hand.house)>21):
                        print("You win: Dealer is > 21)")
                        self.record.increasePlayerScore()
                    else:
                        self.hand.compareHands(self.record)
                except OutOfCards:
                    self.record.printRecord()
                    return self.record.getRecord()        
            self.hand = Hand()

#def userinput(str):
#    ans = random.randrange(0,2)
#    if ans:
#        return('s')
#    else:
#        return('h')


#player=0
#dealer=0
#for i in range(10):
#    b=Blackjack()
#    r = b.playBlackjack()
#    player += r.getPlayerWins()
#    dealer += r.getHouseWins()