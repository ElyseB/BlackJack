from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for, session
)
from werkzeug.exceptions import abort

from game.auth import login_required
import random
from blackjackgame import *

bp = Blueprint('game', __name__)

def handtoList(hand):
    dealer=[]
    player=[]
    for card in hand.house:
        dealer=dealer+[card.getRank(), card.getSuit()]
    for card in hand.player:
        player=player+[card.getRank(), card.getSuit()]
    return [dealer,player]

def listtoHand(handlist):
    hand=Hand()
    for index in range(0,len(handlist[0])-1,2):
        hand.houseAddACard(Card(handlist[0][index], handlist[0][index+1]))
    for index in range(0,len(handlist[1])-1,2):
        hand.playerAddACard(Card(handlist[1][index], handlist[1][index+1]))
    return hand
   
def prettyCards(hand):
    cards=[[],[]]
    for index in range(len(hand.house)):
        cards[0]=cards[0] + [hand.house[index].prettyString()]
    for index in range(len(hand.player)):
        cards[1]=cards[1] + [hand.player[index].prettyString()]
    return cards

def decktoList(deck):
    decklist=[]
    for card in deck.deck:
        decklist = decklist + [card.getRank(),card.getSuit()]
    return decklist

def listtoDeck(decklist):
    deck=Deck()
    deck.emptyDeck()
    for index in range(0,len(decklist)-1,2):
        deck.deckAddACard(Card(decklist[index], decklist[index+1]))
    return deck
    
def loadRecord(score):
    record=Record()
    record.playerwins=score[0]
    record.housewins=score[1]
    record.playerties=score[2]
    return record

@bp.route('/startgame', methods=('GET','POST'))
@login_required
def startgame():
    hand=Hand()
    try:
        deck=listtoDeck(session[str(session['user_id'])+'user'][2])
        record=loadRecord(session[str(session['user_id'])+'user'][3])
    except:
        record=Record()
        deck=Deck()
        deck.shuffle()
    try:
        hand.initialHand(deck)
    except OutOfCards:
        return redirect(url_for('game.outofcards'))
    session[str(session['user_id'])+'user']=handtoList(hand) + [decktoList(deck)] + [record.getRecord()]
    return redirect(url_for('game.askuser'))

@bp.route('/askuser', methods=('GET','POST'))
@login_required
def askuser():
    try:
        hand=listtoHand(session[str(session['user_id'])+'user'])
    except:
        redirect(url_for('game.startgame'))
    if len(hand.house) == 0:
        redirect(url_for('game.startgame'))
    deck=listtoDeck(session[str(session['user_id'])+'user'][2])
    record=loadRecord(session[str(session['user_id'])+'user'][3])
    cards=prettyCards(hand)
    housecards=cards[0];playercards=cards[1]
    if request.method=='POST':
        try:
            card=deck.dealCard()
        except OutOfCards:
            return redirect(url_for('game.outofcards'))
        hand.playerAddACard(card)
        playercards.append(card.prettyString())
    session[str(session['user_id'])+'user']=handtoList(hand) + [decktoList(deck)] + [record.getRecord()]
    if hand.total(hand.player) > 21 and len(hand.house) != 0:
        record.increaseHouseScore()
        session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
        return redirect(url_for('game.housewins'))
    return render_template('game/askuser.html',playercards=playercards,housecards=housecards)

@bp.route('/dealerplay', methods=('GET','POST'))
@login_required
def dealerplay():
    try:
        hand=listtoHand(session[str(session['user_id'])+'user'])
    except:
        redirect(url_for('game.startgame'))
    if len(hand.player) == 0:
        redirect(url_for('game.startgame'))
    deck=listtoDeck(session[str(session['user_id'])+'user'][2])
    record=loadRecord(session[str(session['user_id'])+'user'][3])
    cards=prettyCards(hand)
    housecards=cards[0];playercards=cards[1]
    while hand.total(hand.house) < 17 and len(hand.player) != 0:
        try:
            card = deck.dealCard()
        except OutOfCards:
            return redirect(url_for('game.outofcards'))
        hand.houseAddACard(card)
        housecards.append(card.prettyString())
    houseTotal, playerTotal = hand.total(hand.house), hand.total(hand.player)
    if len(hand.player) != 0:
        if houseTotal > 21:
            record.increasePlayerScore()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.playerwins'))
        elif houseTotal > playerTotal:
            record.increaseHouseScore()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.housewins'))
        elif houseTotal < playerTotal:
            record.increasePlayerScore()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.playerwins'))
        elif houseTotal == 21 and 2 == len(hand.house) < len(hand.player):
            record.increaseHouseScore()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.housewins'))
        elif playerTotal == 21 and 2 == len(hand.player) < len(hand.house):
            record.increasePlayerScore()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.playerwins'))
        else:
            record.increasePlayerTies()
            session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()] + handtoList(hand)
            return redirect(url_for('game.playerties'))
    return render_template('game/dealerplay.html',playercards=playercards,housecards=housecards)

@bp.route('/playerwins',methods=('GET','POST'))
@login_required
def playerwins():
    hand=listtoHand(session[str(session['user_id'])+'user'][4:])
    cards=prettyCards(hand)
    housecards=cards[0];playercards=cards[1]
    return render_template('game/playerwins.html',playercards=playercards,housecards=housecards)

@bp.route('/housewins',methods=('GET','POST'))
@login_required
def housewins():
    hand=listtoHand(session[str(session['user_id'])+'user'][4:])
    cards=prettyCards(hand)
    housecards=cards[0];playercards=cards[1]
    return render_template('game/housewins.html',playercards=playercards,housecards=housecards)

@bp.route('/playerties',methods=('GET','POST'))
@login_required
def playerties():
    hand=listtoHand(session[str(session['user_id'])+'user'][4:])
    cards=prettyCards(hand)
    housecards=cards[0];playercards=cards[1]
    return render_template('game/playerties.html',playercards=playercards,housecards=housecards)
           
@bp.route('/')
def index():
    return render_template('game/welcome.html')

@bp.route('/outofcards',methods=('GET','POST'))
@login_required
def outofcards():
    record=loadRecord(session[str(session['user_id'])+'user'][3])
    deck=listtoDeck(session[str(session['user_id'])+'user'][2])
    deck=Deck()
    deck.shuffle()
    scores=record.getRecord()
    playerwins=scores[0]
    housewins=scores[1]
    playerties=scores[2]
    totalgames=scores[3]
    winpercent=scores[4]
    session[str(session['user_id'])+'user']=[[]] + [[]] + [decktoList(deck)] + [record.getRecord()]
    return render_template('game/outofcards.html',playerwins=playerwins,housewins=housewins,playerties=playerties,totalgames=totalgames,winspercent=winpercent)